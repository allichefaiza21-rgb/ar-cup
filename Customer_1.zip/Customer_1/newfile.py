import os
import shutil

# 1. اطلبي اسم الزبون الجديد
customer_name = input("أدخلي اسم الزبون (بالإنجليزي): ")

# 2. إنشاء مجلد خاص بالزبون لضمان عدم تداخل المشاريع
if not os.path.exists(customer_name):
    os.makedirs(customer_name)
    print(f"✅ تم إنشاء مجلد خاص لـ {customer_name}")

# 3. محتوى كود الـ AR السحري (ثابت لكل الزبائن)
html_content = f"""
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <script src="https://aframe.io/releases/1.5.0/aframe.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/mind-ar@1.2.5/dist/mindar-image-aframe.prod.js"></script>
  </head>
  <body>
    <a-scene mindar-image="imageTargetSrc: targets.mind.txt;" color-space="sRGB" renderer="colorManagement: true, physicallyCorrectLights" vr-mode-ui="enabled: false" device-orientation-permission-ui="enabled: false">
      <a-assets>
        <video id="arVideo" src="video.mp4" preload="auto" loop="true"></video>
      </a-assets>
      <a-camera position="0 0 0" look-controls="enabled: false"></a-camera>
      <a-entity mindar-image-target="targetIndex: 0">
        <a-video src="#arVideo" width="1" height="0.55" position="0 0 0"></a-video>
      </a-entity>
    </a-scene>
    <button style="position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); padding: 10px; z-index: 999;" onclick="document.querySelector('#arVideo').play()">إبدأ التجربة السحرية</button>
  </body>
</html>
"""

# 4. حفظ ملف index.html داخل مجلد الزبون
with open(f"{customer_name}/index.html", "w", encoding="utf-8") as f:
    f.write(html_content)

print(f"🚀 تم تجهيز ملفات {customer_name}! الآن فقط ضعي الفيديو والبصمة داخل مجلده.")
